//
//  AppDelegate.h
//  RWD_Test
//
//  Created by zhaoYuan on 16/12/18.
//  Copyright © 2016年 gongziyuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

