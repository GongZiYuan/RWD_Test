//
//  ViewController.m
//  RWD_Test
//
//  Created by zhaoYuan on 16/12/18.
//  Copyright © 2016年 gongziyuan. All rights reserved.
//

#import "ViewController.h"
#import "TestView.h"

@interface ViewController ()
{
    TestView *testView;
}

@end

@implementation ViewController



static void RunLoopObserverCallBack(CFRunLoopObserverRef observer, CFRunLoopActivity activity, void *info) {
    NSLog(@"runloop kCFRunLoopBeforeWaiting | kCFRunLoopExit");
}

static void RunloopSetUp() {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        CFRunLoopRef runloop = CFRunLoopGetMain();
        CFRunLoopObserverRef observer;
        
        //监听runloop要退出或休眠
        observer = CFRunLoopObserverCreate(CFAllocatorGetDefault(),
                                           kCFRunLoopBeforeWaiting | kCFRunLoopExit,
                                           true,      // repeat
                                           0xFFFFFF,  // after CATransaction(2000000)
                                           RunLoopObserverCallBack, NULL);
        CFRunLoopAddObserver(runloop, observer, kCFRunLoopCommonModes);
        CFRelease(observer);
    });
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    RunloopSetUp();
    
    testView = [[TestView alloc] initWithFrame:CGRectMake(100, 100, 100, 120)];
    testView.backgroundColor = [UIColor redColor];
    
    [self.view addSubview:testView];
    
    UIButton *testBtn = [[UIButton alloc] initWithFrame:CGRectMake(220, 240, 90, 60)];
    [testBtn setBackgroundColor:[UIColor greenColor]];
    [testBtn setTitle:@"testCa" forState:UIControlStateNormal];
    [testBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [testBtn addTarget:self action:@selector(testCA:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:testBtn];
    
}

- (void)testCA:(UIButton*)sender
{
    NSLog(@"testCA");
    
    testView.frame = CGRectMake(0, 0, 100, 120); //在for循环前改变View的frame
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        for (int i = 0; i < 10000; i ++) {
            NSLog(@"testCA---%d",i);
        }

    });
    
//    testView.frame = CGRectMake(0, 300, 100, 120);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
