//
//  TestView.m
//  RWD_Test
//
//  Created by zhaoYuan on 16/12/18.
//  Copyright © 2016年 gongziyuan. All rights reserved.
//

#import "TestView.h"

@implementation TestView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    
    NSLog(@"frame changed!");
}
@end
